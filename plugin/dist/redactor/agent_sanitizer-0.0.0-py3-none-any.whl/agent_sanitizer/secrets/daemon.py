"""Long-lived redaction daemon over a Unix socket.

Spawning a fresh interpreter and reloading the detect-secrets plugin set for
every secret-shaped payload is slow enough to time out under load. This daemon
pays that cost ONCE — :func:`~agent_sanitizer.secrets.configure_plugins` at
startup — then serves each request as just a scan, so a transient stall fails
only that one call and the next succeeds.

Wire protocol (both directions): a 4-byte big-endian unsigned length prefix then
that many bytes of UTF-8 JSON. Request: ``{"text", "map", "web_ingress",
"env_secrets"}``. Response: exactly what a one-shot
:func:`~agent_sanitizer.secrets.handle_request` returns — the response object, or
JSON ``null`` for the "nothing to redact" case, or ``{"error"}`` when the daemon
could not vet the input. ``env_secrets`` is ``name -> value`` supplied per
request (the socket may be shared across sessions, so the daemon must redact the
REQUESTER's keys, not its own environment).
"""

import concurrent.futures
import contextlib
import errno
import fcntl
import json
import os
import socket
import struct
import sys
import threading
import traceback

from . import RedactorConfig, configure_plugins, handle_request
from .engine import redact_configured

# Refuse absurd frames rather than buffer unbounded; the magnitude is arbitrary
# (the cap *boundary* is what matters).
FRAME_CAP = 16 * 1024 * 1024

# Bound on a single ACCEPTED connection's I/O. The listen socket's own
# `settimeout` only governs how often `accept()` re-checks `stop` — it does
# nothing once a connection is accepted, and `_serve_one` is called inline in
# the same accept-loop iteration. Without this, a client that opens a
# connection and never finishes sending its frame (e.g. 3 of 4 header bytes)
# blocks `_recv_exact` forever, which blocks the entire accept loop from ever
# calling `accept()` again — one idle/slow/malicious local client wedges the
# daemon for every other client sharing the socket. Long enough for a
# legitimate large request over a local socket, short enough to bound the DoS
# window.
CONN_TIMEOUT_SECONDS = 10.0

# Accepted connections are handed to a fixed pool of worker threads rather than
# served inline in the accept loop, so one slow/stalled local client can no longer
# wedge every other client sharing the socket (a local DoS). The pool is BOUNDED:
# at most this many requests run concurrently; further accepted connections queue
# and are picked up as workers free. Each worker is itself time-bounded by
# CONN_TIMEOUT_SECONDS, so the queue drains. Small — the daemon is a per-request
# CPU-bound scan, not an I/O fan-out server; a handful of cores' worth is plenty.
WORKER_POOL_SIZE = 8


def _recv_exact(conn: socket.socket, n: int) -> bytes | None:
    """Read exactly ``n`` bytes, or None if the peer closed/reset mid-frame."""
    buf = bytearray()
    while len(buf) < n:
        chunk = conn.recv(n - len(buf))
        if not chunk:
            return None
        buf.extend(chunk)
    return bytes(buf)


def _read_frame(conn: socket.socket) -> object | None:
    """Decode one length-prefixed JSON frame, or None on a closed, short, or
    over-cap connection (the caller fails that one request closed)."""
    header = _recv_exact(conn, 4)
    if header is None:
        return None
    (length,) = struct.unpack(">I", header)
    if length > FRAME_CAP:
        return None
    body = _recv_exact(conn, length)
    if body is None:
        return None
    return json.loads(body.decode("utf-8"))


def _write_frame(conn: socket.socket, obj: object) -> None:
    body = json.dumps(obj).encode("utf-8")
    conn.sendall(struct.pack(">I", len(body)) + body)


def _request_config(req: dict) -> RedactorConfig:
    """Build a per-request config from the wire frame. ``env_secrets`` is filtered
    to str→str (the socket may live in a shared tmpdir, so a request is not fully
    trusted — a non-str value would crash the env-bound length check). The daemon
    always uses the full detector set (high_confidence is a startup-scan concern,
    not a per-request one) and the shared invisible charset."""
    env_secrets = req.get("env_secrets")
    provider_vars = (
        {k: v for k, v in env_secrets.items() if isinstance(v, str)}
        if isinstance(env_secrets, dict)
        else {}
    )
    return RedactorConfig(
        provider_vars=provider_vars,
        # Fail closed: this is a SHARED, UNAUTHENTICATED local socket, so a
        # caller that forgets (or has a buggy client that omits) the flag must
        # get the stronger, non-name-trusting heuristics — not the weaker
        # local-output mode that skips redaction for anything that merely
        # LOOKS like a benign cursor/path/metadata field by variable name.
        # Callers opt into the weaker mode explicitly with `web_ingress: false`.
        web_ingress=bool(req.get("web_ingress", True)),
    )


def _serve_one(conn: socket.socket) -> None:
    """Handle one connection: read a request frame, write the response frame. Any
    per-connection fault closes only this connection — a malformed frame or a
    dropped client must never take the daemon down."""
    try:
        req = _read_frame(conn)
        if not isinstance(req, dict):
            return  # no/garbage request frame: just close this connection
        try:
            result = handle_request(
                str(req.get("text", "")),
                bool(req.get("map", False)),
                _request_config(req),
                redact_configured,
            )
        except Exception as exc:  # noqa: BLE001
            # A genuine detection failure for THIS request: signal the client so it
            # fails THAT call closed, but keep the daemon alive. Log the exception
            # TYPE and its stack FRAMES (never to the client) so a systematic
            # fault — every request failing, not just one malformed one — is
            # visible to whoever operates the daemon. The exception MESSAGE is
            # deliberately withheld: it can embed bytes of the secret-bearing
            # input line (e.g. a re/JSON error echoing the offending text), which
            # must never reach the logs. Frames are static source locations, not
            # runtime data, so they are safe.
            sys.stderr.write(
                f"secret redaction failed ({type(exc).__name__}); "
                "input and exception message withheld from log:\n"
                + "".join(traceback.format_tb(exc.__traceback__))
            )
            _write_frame(conn, {"error": "redaction failed"})
            return
        _write_frame(conn, result)
    except (OSError, ValueError):
        # ValueError: malformed JSON body. OSError: socket reset mid-frame. Both
        # are this client's problem; drop the connection and keep serving.
        pass
    finally:
        conn.close()


def _bind_or_exit(sock: socket.socket, socket_path: str) -> bool:
    """Bind ``sock`` at ``socket_path``; the bind is the cross-process mutex that
    makes a respawn idempotent. Return False (caller exits quietly) when a LIVE
    daemon already owns the path; clear a STALE socket file and rebind otherwise."""
    try:
        sock.bind(socket_path)
    except OSError as exc:
        if exc.errno != errno.EADDRINUSE:
            raise
    else:
        return True
    # The path is occupied. "Is it stale? then unlink and rebind" is a check-then-act
    # that two daemons racing to reclaim the SAME stale path can interleave; serialize
    # that critical section on a sibling lock file.
    lock_path = socket_path + ".lock"
    lock_fd = os.open(lock_path, os.O_CREAT | os.O_RDWR, 0o600)
    try:
        fcntl.flock(lock_fd, fcntl.LOCK_EX)
        return _reclaim_stale_socket(sock, socket_path)
    finally:
        os.close(lock_fd)


def _reclaim_stale_socket(sock: socket.socket, socket_path: str) -> bool:
    """Under the reclaim lock: probe the occupied ``socket_path``. Return False if a
    LIVE daemon answers (we lost the race); otherwise clear the stale file and rebind."""
    probe = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    try:
        probe.connect(socket_path)
    except OSError:
        pass  # nobody listening: a stale socket file
    else:
        return False  # a live daemon answered; we lost the race
    finally:
        probe.close()
    os.unlink(socket_path)
    sock.bind(socket_path)
    return True


def serve(socket_path: str, stop: threading.Event | None = None) -> None:
    """Serve redactions over the Unix socket at ``socket_path`` until ``stop`` is
    set (or forever).

    Configures the detect-secrets plugin set ONCE and primes the mapping cache
    with a warm-up scan BEFORE binding, so a bound socket implies a ready daemon.
    ``stop`` is a graceful-shutdown seam for tests; production passes none.
    """
    socket_dir = os.path.dirname(socket_path) or "."
    os.makedirs(socket_dir, mode=0o700, exist_ok=True)
    # `makedirs(..., mode=...)` only applies `mode` to a directory it actually
    # CREATES — `exist_ok=True` silently accepts a pre-existing dir at ANY
    # permission level, including world-writable (e.g. a shared /tmp subpath
    # another local process claimed first). Enforce the mode so a
    # stale/attacker-seeded directory can't leave the socket reachable.
    #
    # A plain `os.chmod(socket_dir, ...)` re-resolves the PATH: between the
    # makedirs above and the chmod, another local process could swap the final
    # component for a symlink and redirect the chmod onto a directory it owns
    # (TOCTOU). Bind an fd to the real directory instead — O_NOFOLLOW refuses a
    # symlinked final component — and fchmod/fstat through that fd so the check
    # and the change target the same inode. Refuse a directory this uid does not
    # own: tightening someone else's dir to 0o700 neither makes it ours nor
    # makes the socket safe, so fail loudly rather than serve on it.
    dir_fd = os.open(socket_dir, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    try:
        owner = os.fstat(dir_fd).st_uid
        if owner != os.getuid():
            raise PermissionError(
                f"refusing to serve: socket directory {socket_dir!r} is owned by "
                f"uid {owner}, not {os.getuid()}"
            )
        os.fchmod(dir_fd, 0o700)
    finally:
        os.close(dir_fd)
    with configure_plugins():
        redact_configured(
            "warm up the detect-secrets mapping cache", None, RedactorConfig()
        )
        sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        # `bind()` creates the socket file under the process's current umask;
        # narrow the window between file creation and the explicit chmod below
        # by restricting the umask for the bind call itself, so the socket is
        # never briefly world/group-accessible on a permissive parent dir. The
        # protocol is unauthenticated, so a connectable-but-not-yet-restricted
        # socket is a real local privilege issue, not just cosmetic.
        old_umask = os.umask(0o077)
        try:
            bound = _bind_or_exit(sock, socket_path)
        finally:
            os.umask(old_umask)
        if not bound:
            sock.close()
            return
        pool = concurrent.futures.ThreadPoolExecutor(
            max_workers=WORKER_POOL_SIZE, thread_name_prefix="secret-redactor"
        )
        try:
            os.chmod(socket_path, 0o600)  # defense-in-depth; harmless if redundant
            sock.listen(64)
            sock.settimeout(0.5)
            while not (stop is not None and stop.is_set()):
                try:
                    conn, _ = sock.accept()
                except TimeoutError:
                    continue
                # Bound THIS connection's I/O; see CONN_TIMEOUT_SECONDS docstring.
                # The connection is handed to the worker pool (not served inline),
                # so a stalled peer occupies only one worker instead of wedging the
                # accept loop. `_serve_one` always closes its own conn.
                conn.settimeout(CONN_TIMEOUT_SECONDS)
                pool.submit(_serve_one, conn)
        finally:
            # Stop accepting, then drain in-flight handlers so no connection is
            # dropped mid-response. Each worker is bounded by CONN_TIMEOUT_SECONDS,
            # so this wait terminates. Close the listen socket and unlink the path
            # only after the pool has quiesced.
            pool.shutdown(wait=True)
            sock.close()
            with contextlib.suppress(OSError):
                os.unlink(socket_path)


def main(argv: list[str] | None = None) -> None:
    """CLI: ``agent-secret-redactor-daemon <socket-path>``."""
    args = sys.argv[1:] if argv is None else argv
    if len(args) != 1:
        raise SystemExit("usage: agent-secret-redactor-daemon <socket-path>")
    serve(args[0])
