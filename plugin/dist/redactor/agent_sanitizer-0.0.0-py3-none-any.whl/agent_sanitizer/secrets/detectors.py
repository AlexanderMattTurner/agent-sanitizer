# detect-secrets' BasePlugin/RegexBasedDetector declare `secret_type` and `denylist`
# as abstract properties whose documented override is a plain class variable (see the
# base class docstring). Every detector below follows that intended pattern, so
# pyright's property-override and assignment-type checks are false positives here;
# this module holds nothing but those detector classes plus the denylist loader.
# pyright: reportIncompatibleMethodOverride=false, reportAssignmentType=false
"""Custom detect-secrets plugins for credential formats the bundled detectors
lack.

Each class is the detect-secrets *adapter* for one entry in
``data/secret-detectors.json`` — the single source of truth for these regex
patterns. The class keeps the name the engine loads it by (``CUSTOM_PLUGINS`` in
``engine.py``) and supplies the detect-secrets ``secret_type`` label; its
``denylist`` is compiled from the shared file. When detect-secrets gains a native
detector for one of these, drop the class here and the JSON entry.

detect-secrets has no Google or Anthropic detector (verified against its plugin
list); both are credential formats a coding agent's tool output can leak, so they
must be redacted before the model sees them.

The pure-regex classes load their ``denylist`` from the shared JSON. The one
structural exception is ``JwtFullTokenDetector``, which subclasses a bundled
detector to keep its base64/JSON validation and so carries its own regex inline
rather than a JSON entry.
"""

import base64
import json
import re
from pathlib import Path

# Imported as a MODULE, not `from … import JwtTokenDetector`: detect-secrets'
# custom-plugin loader (get_plugins_from_file) scans this module's attributes for
# any BasePlugin subclass and keys them by secret_type, so a bare
# ``JwtTokenDetector`` name in scope would be re-registered under "JSON Web Token"
# and, sorting after JwtFullTokenDetector, overwrite it — leaving the subclass
# unfindable by classname ("No such JwtFullTokenDetector plugin"). A module
# attribute is not a class, so the scanner ignores it.
from detect_secrets.plugins import jwt as _jwt
from detect_secrets.plugins.base import RegexBasedDetector

# Compiled denylists keyed by detector class name, loaded from the shared SSOT
# packaged alongside this module. Patterns are constrained to a JS-portable regex
# subset (see the file's `description`); that constraint is enforced by
# test/secret-detectors-portability.test.mjs, which compiles every pattern with
# the real JS `RegExp` — not re-approximated here in Python.
DETECTORS_FILE = Path(__file__).resolve().parent / "data" / "secret-detectors.json"
_DENYLISTS = {
    entry["const"]: [re.compile(pattern) for pattern in entry["patterns"]]
    for entry in json.loads(DETECTORS_FILE.read_text())["detectors"]
}


class AnthropicApiKeyDetector(RegexBasedDetector):
    """Anthropic API keys (``sk-ant-…``). gitleaks rule: ``anthropic-api-key``."""

    secret_type = "Anthropic API Key"  # noqa: S105 — a detector label, not a secret
    denylist = _DENYLISTS["AnthropicApiKeyDetector"]


class GoogleApiKeyDetector(RegexBasedDetector):
    """Google / GCP API keys (``AIza…``). gitleaks rule: ``gcp-api-key``."""

    secret_type = "Google API Key"  # noqa: S105 — a detector label, not a secret
    denylist = _DENYLISTS["GoogleApiKeyDetector"]


class DigitalOceanTokenDetector(RegexBasedDetector):
    """DigitalOcean tokens (``do{o,p,r}_v1_…``). gitleaks rules:
    ``digitalocean-access-token`` (``doo_``), ``digitalocean-pat`` (``dop_``),
    ``digitalocean-refresh-token`` (``dor_``)."""

    secret_type = "DigitalOcean Token"  # noqa: S105 — a detector label, not a secret
    denylist = _DENYLISTS["DigitalOceanTokenDetector"]


class CloudflareOriginCaKeyDetector(RegexBasedDetector):
    """Cloudflare Origin CA keys (``v1.0-…``). gitleaks rule:
    ``cloudflare-origin-ca-key``. The keyword-context ``cloudflare-api-key`` /
    ``cloudflare-global-api-key`` rules have no standalone shape (skipped in the
    triage)."""

    secret_type = "Cloudflare Origin CA Key"  # noqa: S105 — a detector label, not a secret
    denylist = _DENYLISTS["CloudflareOriginCaKeyDetector"]


class VaultTokenDetector(RegexBasedDetector):
    """HashiCorp Vault tokens (``hvs.…`` service, ``hvb.…`` batch). gitleaks
    rules: ``vault-service-token``, ``vault-batch-token``. The legacy ``s.<24>``
    form is deliberately omitted — too generic to match without false positives."""

    secret_type = "Vault Token"  # noqa: S105 — a detector label, not a secret
    denylist = _DENYLISTS["VaultTokenDetector"]


class HashiCorpTerraformTokenDetector(RegexBasedDetector):
    """Terraform Cloud / Enterprise API tokens (``….atlasv1.…``). gitleaks rule:
    ``hashicorp-tf-api-token``."""

    secret_type = "Terraform Cloud API Token"  # noqa: S105 — a detector label, not a secret
    denylist = _DENYLISTS["HashiCorpTerraformTokenDetector"]


class GitHubFineGrainedPatDetector(RegexBasedDetector):
    """GitHub fine-grained PATs (``github_pat_…``). gitleaks rule:
    ``github-fine-grained-pat``. detect-secrets' ``GitHubTokenDetector`` only
    matches the ``gh[pousr]_`` classic-token prefixes, not ``github_pat_``."""

    secret_type = "GitHub Fine-Grained PAT"  # noqa: S105 — a detector label, not a secret
    denylist = _DENYLISTS["GitHubFineGrainedPatDetector"]


# ── Formats with no gitleaks default rule ────────────────────────────────────
# gitleaks does not ship a rule for these, so the regex is sourced from the
# provider's own key shape rather than a gitleaks rule. Keys with no distinctive
# structural shape (e.g. Venice — verified to have no documented prefix) are
# redacted by env-var-value binding (RedactorConfig.env_secrets) instead, not
# here, since a bare-token regex would either over-redact or miss.


class OpenRouterApiKeyDetector(RegexBasedDetector):
    """OpenRouter API keys (``sk-or-v1-…``). No gitleaks rule; the ``sk-or-v1-``
    prefix is verified from OpenRouter's docs and the 64-hex body from observed
    keys (https://openrouter.ai/docs/api/reference/authentication)."""

    secret_type = "OpenRouter API Key"  # noqa: S105 — a detector label, not a secret
    denylist = _DENYLISTS["OpenRouterApiKeyDetector"]


class GroqApiKeyDetector(RegexBasedDetector):
    """Groq API keys (``gsk_…``). No gitleaks rule; prefix from Groq's console
    docs (https://console.groq.com/keys)."""

    secret_type = "Groq API Key"  # noqa: S105 — a detector label, not a secret
    denylist = _DENYLISTS["GroqApiKeyDetector"]


class XaiApiKeyDetector(RegexBasedDetector):
    """xAI / Grok API keys (``xai-…``). No gitleaks rule; prefix from xAI's docs
    (https://docs.x.ai/overview)."""

    secret_type = "xAI API Key"  # noqa: S105 — a detector label, not a secret
    denylist = _DENYLISTS["XaiApiKeyDetector"]


class ReplicateApiTokenDetector(RegexBasedDetector):
    """Replicate API tokens (``r8_…``). No gitleaks rule; prefix from Replicate's
    docs (https://replicate.com/docs/topics/security/api-tokens)."""

    secret_type = "Replicate API Token"  # noqa: S105 — a detector label, not a secret
    denylist = _DENYLISTS["ReplicateApiTokenDetector"]


# ── Reimplementations of bundled detectors with a capture-group leak ──────────
# detect-secrets' GitHubTokenDetector and GitLabTokenDetector wrap the token
# PREFIX in a capturing group, and detect-secrets reports re.findall's group as
# the secret value — so the redactor replaced only the prefix and left the token
# body in cleartext. These replace the built-ins (dropped from PLUGINS in
# engine.py) with NON-capturing groups so findall returns the whole match and the
# full token redacts. secret_type is identical to the built-in's.


class GitHubClassicTokenDetector(RegexBasedDetector):
    """Classic GitHub tokens (``gh[pousr]_``). Non-capturing reimplementation of
    the bundled ``GitHubTokenDetector`` (which leaked the body). gitleaks rules:
    ``github-pat`` / ``github-oauth`` / ``github-app-token`` /
    ``github-refresh-token``."""

    secret_type = "GitHub Token"  # noqa: S105 — a detector label, not a secret
    denylist = _DENYLISTS["GitHubClassicTokenDetector"]


class GitLabAccessTokenDetector(RegexBasedDetector):
    """GitLab PATs and CI/deploy/runner tokens (``glpat-``/``glcbt-``/…).
    Non-capturing reimplementation of the bundled ``GitLabTokenDetector`` (which
    leaked the body). gitleaks rules: ``gitlab-pat`` and the other ``gitlab-*``
    token rules."""

    secret_type = "GitLab Token"  # noqa: S105 — a detector label, not a secret
    denylist = _DENYLISTS["GitLabAccessTokenDetector"]


# ── Reimplementation of a bundled detector with a lazy-quantifier leak ────────
# Unlike the GitHub/GitLab capture-group cases above, this detector is
# structural (it keeps detect-secrets' base64/JSON validation), so its regex is
# NOT a pure-regex SSOT entry — it subclasses the bundled JwtTokenDetector and
# overrides only the denylist. The bundled regex ends the signature segment with
# a LAZY ``[A-Za-z0-9-_.+/=]*?``, which matches the *minimal* JWT (``header.
# payload.``) and leaves the signature in cleartext; the redactor then replaced
# only ``header.payload.`` and emitted ``[REDACTED: JSON Web Token]<signature>``.
# A GREEDY signature segment (no trailing ``?``) consumes the whole token so the
# full JWT redacts. The signature class excludes ``.`` so a greedy match can
# never spill past the three segments into trailing text. is_formally_valid is
# overridden to gate on the header/payload base64url-JSON only — see its docstring
# for why the bundled signature padding check leaks real tokens.


class JwtFullTokenDetector(_jwt.JwtTokenDetector):
    """JSON Web Tokens, redacting the signature the bundled detector leaks.
    Subclasses ``JwtTokenDetector`` to keep its base64/JSON validation; only the
    signature quantifier changes from lazy to greedy. gitleaks rule: ``jwt``."""

    # Per-segment quantifiers are BOUNDED ({1,65536}) rather than ``+``: an
    # unbounded run retried at every ``eyJ`` start makes an unanchored search
    # polynomial, and a finite bound is provably linear. The bound must clear a
    # full RFC 7515 header carrying an ``x5c`` certificate CHAIN — several base64
    # DER certs run well past 8192 chars, and a header that overflowed the bound
    # matched NOTHING and leaked the whole JWT in cleartext. 65536 base64
    # chars/segment dwarfs even a multi-cert chain while staying linear. The
    # third segment is optional so unsigned (``header.payload.``) and two-part
    # JWTs still match, exactly as the bundled detector did.
    # noqa rationale: detect-secrets' RegexBasedDetector declares `denylist` as an
    # instance attribute, so a ClassVar annotation errors pyright; the subclass sets it
    # as a class attribute by framework contract, which is the shared-state RUF012 flags.
    denylist = [  # noqa: RUF012
        re.compile(
            r"eyJ[A-Za-z0-9_=-]{1,65536}\.[A-Za-z0-9_=-]{1,65536}"
            r"(?:\.[A-Za-z0-9_=-]{0,65536})?"
        ),
    ]

    @staticmethod
    def is_formally_valid(token: str) -> bool:
        """Validate ONLY the header and payload as base64url JSON. The bundled
        validator also padding-checks the signature, but the signature is opaque
        bytes, not JSON, and its length need not be a multiple of four. When the
        greedy regex absorbs a trailing base64url char from adjacent text (or a
        genuine signature simply has length ≡ 1 mod 4), that padding check raises
        "Incorrect padding" and discards the whole real token — leaking it. The
        ``eyJ``-anchored base64url-JSON gate on the first two segments is what
        actually rejects false positives; the signature needs no structural check
        (the regex already constrains it to base64url, with ``.`` excluded so a
        greedy match can't spill past the token)."""
        for part_str in token.split(".")[:2]:
            try:
                part = part_str.encode("ascii")
                if len(part) % 4 == 1:
                    return False
                part += b"=" * (-len(part) % 4)
                json.loads(base64.urlsafe_b64decode(part).decode("utf-8"))
            except (TypeError, ValueError, UnicodeDecodeError):
                return False
        return True
