/**
 * Re-anchor an Edit/Write input composed from a sanitized file view back onto
 * the on-disk bytes (secrets rehydrated, stripped invisible runs re-attached).
 * Returns the rewritten input plus a model-facing context line, a deny with an
 * instructive reason when the input is unresolvable or would expose a secret,
 * or null when there is nothing to do. Throws only on internal error (the
 * caller fails closed).
 *
 * `io` is the injected I/O (file read + redactor map/plain). `hint` is the
 * redaction-placeholder prefix (defaults to {@link DEFAULT_HINT}); override it
 * only if the injected redactor emits a different placeholder shape.
 * @param {string} tool
 * @param {any} toolInput
 * @param {RehydrateIo} io
 * @param {{ hint?: string }} [options]
 * @returns {Promise<{updatedInput: any, context: string} | {deny: string} | null>}
 */
export function rehydrateRedacted(tool: string, toolInput: any, io: RehydrateIo, { hint }?: {
    hint?: string;
}): Promise<{
    updatedInput: any;
    context: string;
} | {
    deny: string;
} | null>;
export const DEFAULT_HINT: "[REDACTED";
/**
 * Map-mode response from the redactor: either the mappable view (text + ordered
 * (placeholder, original, start) pairs) or an unmappable verdict carrying its
 * reason — a discriminated pair.
 */
export type RedactMapView = {
    text: string;
    pairs: {
        placeholder: string;
        original: string;
        start: number;
    }[];
} | {
    unmappable: string;
};
/**
 * Injected I/O. `readFile` returns the file's bytes (throwing on a missing or
 * unreadable path). `redactMap` returns the redacted view of (Layer-1-cleaned)
 * file text plus the ordered (placeholder, original, start) pairs, or an
 * `{unmappable}` verdict. `redact` returns the plain redacted text, or null
 * when nothing was redacted. `redactMap`/`redact` are the only secret-engine
 * seam; they may be async and are awaited.
 */
export type RehydrateIo = {
    readFile: (path: string) => string;
    redactMap: (text: string) => Promise<RedactMapView> | RedactMapView;
    redact: (text: string) => Promise<string | null> | (string | null);
};
