/**
 * Human-facing block reason: what was detected, the thresholds, a code-point
 * sample of the long run (if any), and how to recover.
 * @param {string[]} categories
 * @param {number} invisibleCount
 * @param {string | null} longRunSample
 * @returns {string}
 */
export function formatReason(categories: string[], invisibleCount: number, longRunSample: string | null): string;
/**
 * Pure verdict for a user prompt: pass through, pass with an SGR note, or
 * block. `strip` (the ANSI stripper, defaulting to the package's
 * {@link stripAnsiFully}) runs on every prompt so invisibles smuggled *inside*
 * an ANSI sequence (an OSC string) are stripped before the invisible-char
 * thresholds are counted; it is injectable so a host can substitute its own
 * stripper or exercise the fail-closed path.
 * @param {string} prompt
 * @param {(s: string) => string} [strip]
 * @returns {{action:"pass"} | {action:"note"} | {action:"block", reason:string}}
 */
export function classifyPrompt(prompt: string, strip?: (s: string) => string): {
    action: "pass";
} | {
    action: "note";
} | {
    action: "block";
    reason: string;
};
