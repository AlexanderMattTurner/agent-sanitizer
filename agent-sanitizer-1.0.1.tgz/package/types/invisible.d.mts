/**
 * True when every ANSI control introducer in `text` belongs to a display-only
 * SGR color sequence (so stripping the ANSI removed only cosmetic styling,
 * nothing that could move the cursor, erase, or carry a payload). Recognizes
 * both the 7-bit `ESC[…m` and 8-bit C1 (`U+009B…m`) SGR encodings.
 * @param {string} text
 * @returns {boolean}
 */
export function isSgrOnly(text: string): boolean;
/**
 * The agent-facing "Stripped: …" note for a Layer-1 strip: the removed category
 * labels, the LONG RUN marker when the de-ANSI'd text still holds a
 * payload-length invisible run, and a pointer to recover the bytes — a hex dump
 * is ASCII, so it passes through sanitization untouched. The single source of
 * this note, shared by the `sanitize` convenience entry and the tool-output
 * pipeline so the two can't drift.
 * @param {string[]} invisFound CATEGORY codes applyLayer1 reported removing
 * @param {string} deAnsi ANSI-stripped text (invisible runs intact), for the LONG_RUN probe
 * @returns {string}
 */
export function describeStripped(invisFound: string[], deAnsi: string): string;
/**
 * Count the PAYLOAD invisible code points in `text`: those the carve-out would
 * strip, excluding ZWNJ/ZWJ (and emoji VS16) that do real rendering work.
 * Consumers that gate on invisible density (e.g. the prompt classifier's scatter
 * threshold) use this so legitimate dense multilingual prose is not mistaken for
 * a hidden channel.
 * @param {string} text
 * @returns {number}
 */
export function countPayloadInvisible(text: string): number;
/**
 * The `text` with every carve-out-PRESERVABLE invisible (joiners/selectors/tags/
 * blank fillers doing real rendering work) replaced by a space, leaving only the
 * PAYLOAD invisibles in place. The LONG_RUN injection probe runs over this so a
 * legitimate emoji/flag/variation sequence never trips the "possible injection
 * payload" marker (alert fatigue), while a genuine hidden run still surfaces.
 * @param {string} text
 * @returns {string}
 */
export function payloadInvisibleView(text: string): string;
/**
 * Strip payload-capable invisible chars and report which categories were
 * removed. A single leading U+FEFF (BOM) is preserved as a legitimate marker;
 * interior BOMs and all soft hyphens (U+00AD) are stripped, since either can
 * encode hidden instructions. ZWNJ/ZWJ survive only in a linguistic context
 * (see the carve-out above). `found` names exactly the categories stripped, so
 * a caller never warns about a strip the carve-out skipped.
 *
 * `originalText` is the pre-processing text (before any ANSI strip) used ONLY to
 * decide whether a leading BOM is genuinely leading: an interior BOM that an
 * ANSI-strip left at index 0 of `text` (e.g. `ESC[m + interior U+FEFF`) must NOT be treated as a
 * legitimate leading marker. Defaults to `text` for the common single-arg call.
 * @param {string} text
 * @param {string} [originalText]
 * @returns {{ cleaned: string, found: string[] }}
 */
export function stripInvisibleWithReport(text: string, originalText?: string): {
    cleaned: string;
    found: string[];
};
/**
 * Strip payload-capable invisible chars (cleaned text only). See
 * stripInvisibleWithReport for the BOM and ZWNJ/ZWJ carve-out semantics.
 * @param {string} text
 * @returns {string}
 */
export function stripInvisible(text: string): string;
export const VS: string;
export const ZERO_WIDTH_MN: "\u034F\u17B4\u17B5";
export const BLANK_NON_CF: string;
export const CATEGORY: Readonly<{
    CF: "cf-format";
    VARIATION_SELECTORS: "variation-selectors";
    BLANK_FILLERS: "blank-fillers";
    ANSI: "ansi";
    LONE_SURROGATES: "lone-surrogates";
    HTML_COMMENTS: "html-comments";
    HIDDEN_HTML: "hidden-html";
    EXFIL_URLS: "exfil-urls";
}>;
/** @type {Readonly<Record<string, string>>} */
export const CATEGORY_LABELS: Readonly<Record<string, string>>;
/** @type {Array<[string, RegExp]>} Each entry pairs a CATEGORY code with its detector. */
export const CHECKS: Array<[string, RegExp]>;
export const STRIP: RegExp;
export const SGR_RE: RegExp;
export const LONG_RUN_THRESHOLD: 10;
/** Total invisible-char count above which a file/prompt is treated as
 * payload-capable even without a long run (threshold-evasion catch). */
export const SCATTERED_THRESHOLD: 30;
export const LONG_RUN_RE: RegExp;
export const CONSECUTIVE_JOINER_CAP: 8;
export const CONSECUTIVE_SELECTOR_CAP: 8;
export const TOTAL_PRESERVED_JOINER_BUDGET: 16;
export const PRESERVED_JOINER_PER_VISIBLE: 8;
export const PRESERVE_HARD_CAP: 64;
export const LINGUISTIC_SCRIPTS: string[];
