/**
 * Dispatch to the hook named by `--hook=<name>` in argv. Exported and guarded by
 * isMain below so importing this module (the published entry point) is a no-op:
 * only a direct `node plugin-hooks.mjs --hook=…` run consumes stdin and exits.
 * @returns {Promise<void>}
 */
export function main(): Promise<void>;
