/**
 * Compose the four protections. Returns the `hookSpecificOutput` fields to
 * emit, or null for a clean no-op. Throws only if a layer's engine throws; the
 * caller fails closed (ask) on any throw. Every exit routes through emitTraced.
 * @param {any} input parsed PreToolUse event
 * @param {(tool: string, toolInput: any) => ReturnType<typeof rehydrateRedacted>} [rehydrate]
 * injectable for tests; the default binds the real redactor-daemon io (the
 * layer reads the target file and maps secrets through the daemon)
 * @returns {Promise<Record<string, unknown> | null>}
 */
export function buildPreToolUseResponse(input: any, rehydrate?: (tool: string, toolInput: any) => ReturnType<typeof rehydrateRedacted>): Promise<Record<string, unknown> | null>;
/**
 * Agent-agnostic judge over the four protections: consumes a control-plane
 * ToolCallEvent and returns a Verdict, so a non-Claude host can run the same
 * sanitization pipeline through its own adapter. The wired Claude CLI below
 * routes through this judge and renders the Verdict with the Claude adapter; on
 * any throw (a control-plane package-load failure included) it falls back to
 * failClosedFields — a native response that needs no package — so the
 * fail-closed posture holds even when the adapter never loaded.
 * @param {import("agent-control-plane-core").ToolCallEvent} event
 * @param {(tool: string, toolInput: any) => ReturnType<typeof rehydrateRedacted>} [rehydrate]
 * @param {{ messages?: Partial<typeof PRE_TOOL_USE_MESSAGES>, gates?: HostGate[] }} [opts]
 *   messages are merged over the defaults, so a partial table is supported
 * @returns {Promise<import("agent-control-plane-core").Verdict>}
 */
export function judgePreToolUseSanitize(event: import("agent-control-plane-core").ToolCallEvent, rehydrate?: (tool: string, toolInput: any) => ReturnType<typeof rehydrateRedacted>, opts?: {
    messages?: Partial<typeof PRE_TOOL_USE_MESSAGES>;
    gates?: HostGate[];
}): Promise<import("agent-control-plane-core").Verdict>;
/**
 * The dependency-load failure hiding behind a hook error, or "". A binding that
 * never loaded surfaces at use time as a bare TypeError ("X is not a function")
 * that names neither the package nor the remedy; when any lazily-loaded package
 * has a recorded load error, name it — the failed set is derived from the
 * loader's own records, so a future dependency is covered without editing a list
 * here. An error already reporting a missing package (missingPackageError's
 * `DEP_UNAVAILABLE` tag) gets no second copy.
 * @param {unknown} err
 * @param {string} [remedy]  what a reader should run; hosts pass their own
 * @param {() => string[]} [failedPackages]
 * @param {(pkg: string) => unknown} [loadErrorFor]
 * @returns {string}
 */
export function depLoadHint(err: unknown, remedy?: string, failedPackages?: () => string[], loadErrorFor?: (pkg: string) => unknown): string;
/**
 * The fail-closed hookSpecificOutput fields for a hook-level failure, chosen by
 * WHICH failure it was. Corrupt/unparsable INPUT (`parsedOk` false — a JSON parse
 * error or the oversize-body cap) is a state an adversary can induce with no
 * upside to failing, so it hard-DENIES: no human to talk past, no approval
 * fatigue, no latency. A LAYER/engine throw after a clean parse (`parsedOk` true
 * — redactor daemon down, package not loaded) is the sanitizer being UNAVAILABLE,
 * so it ASKS to keep a human in the loop rather than hard-block on infrastructure.
 * @param {boolean} parsedOk whether the input parsed before the failure
 * @param {unknown} err
 * @param {{ messages?: Partial<typeof PRE_TOOL_USE_MESSAGES>, hint?: string }} [opts]
 * @returns {Record<string, unknown>}
 */
export function failClosedFields(parsedOk: boolean, err: unknown, opts?: {
    messages?: Partial<typeof PRE_TOOL_USE_MESSAGES>;
    hint?: string;
}): Record<string, unknown>;
/**
 * The hook's CLI: parse → judge → render, with this hook's fail-closed posture.
 * Exported so a bundle entry (which must claim the CLI slot before this module
 * loads) can run the exact same wiring instead of duplicating the onError
 * posture.
 * @param {{
 *   messages?: Partial<typeof PRE_TOOL_USE_MESSAGES>,
 *   gates?: HostGate[],
 * }} [opts]
 * @returns {Promise<void>}
 */
export function cliMain(opts?: {
    messages?: Partial<typeof PRE_TOOL_USE_MESSAGES>;
    gates?: HostGate[];
}): Promise<void>;
/**
 * A host-supplied deny gate: given the PreToolUse input, the reason this call
 * must be blocked, or null to let the pipeline continue. Hosts use these for
 * policy the package has no view of (a required workflow step, a project-local
 * rule); the package ships none.
 * @typedef {(input: { tool_name: string | null, tool_input: any, session_id?: string })
 *   => string | null | undefined} HostGate
 */
/**
 * The reasons this hook emits, as a table a host overrides. A host that knows
 * which of ITS files wires the adapter, and what a reader should do about a
 * failure, can say so — the package cannot, since it has no idea where it is
 * installed.
 * @type {Readonly<{
 *   unknownEvent: string,
 *   failed: (cause: string) => string,
 *   unparsable: (cause: string) => string,
 *   remedy: string,
 * }>}
 */
export const PRE_TOOL_USE_MESSAGES: Readonly<{
    unknownEvent: string;
    failed: (cause: string) => string;
    unparsable: (cause: string) => string;
    remedy: string;
}>;
/**
 * A host-supplied deny gate: given the PreToolUse input, the reason this call
 * must be blocked, or null to let the pipeline continue. Hosts use these for
 * policy the package has no view of (a required workflow step, a project-local
 * rule); the package ships none.
 */
export type HostGate = (input: {
    tool_name: string | null;
    tool_input: any;
    session_id?: string;
}) => string | null | undefined;
declare const rehydrateRedacted: typeof import("agent-sanitizer/rehydrate").rehydrateRedacted;
export {};
