/**
 * Regex matching `value` tolerating invisible chars spliced between its
 * characters (mirrors the engine's env-value regex). Code-point split so
 * an astral character is escaped whole, not as two surrogate halves.
 * @param {string} value
 * @returns {RegExp}
 */
export function envValueRegex(value: string): RegExp;
/**
 * True when tool output contains the literal value of a configured env-bound
 * secret. The shape-based secret hint can't match a prefix-less key or a host
 * credential, so the pre-gate must also fire on the value itself — otherwise
 * the engine's env-bound redaction never runs. Invisible-tolerant so a
 * value with spliced Cf chars (which the daemon still redacts) trips it too.
 * @param {string} text
 * @param {NodeJS.ProcessEnv} [env]
 * @returns {boolean}
 */
export function hasEnvBoundSecret(text: string, env?: NodeJS.ProcessEnv): boolean;
