/**
 * The alert findings if invisible-char injection was detected in instruction
 * files and couldn't be auto-cleaned, else null. ALERT_FILE lives at a predictable,
 * world-visible $TMPDIR path, so its contents are attacker-writable (a co-tenant can
 * plant a file/symlink there): trust it only when markerIsTrusted confirms a regular
 * file THIS uid owns (a squatted symlink/foreign file reads as no alert), then scrub
 * the bytes through Layer-1 before any caller splices them into a reason — the report
 * would otherwise carry ANSI/invisible spoofing into the model's context.
 * @returns {string | null}
 */
export function invisibleCharAlert(): string | null;
/**
 * True once the gate has surfaced its blocking ask this session. Validates
 * ownership (not mere existence): a co-tenant could pre-create ALERT_ACK_FILE at its
 * predictable $TMPDIR path to permanently suppress the one-time blocking ask down to
 * the passive reminder, so trust the marker only when it is a regular file this uid
 * wrote (markerIsTrusted), mirroring how acknowledgeAlert writes it.
 * @returns {boolean}
 */
export function alertAcknowledged(): boolean;
/**
 * Record that the gate has surfaced its blocking ask, so later tool calls get a
 * passive reminder instead of an ask on every call. Cleared at SessionStart by
 * the scanner so each fresh session re-asks once.
 * @returns {void}
 */
export function acknowledgeAlert(): void;
/**
 * @param {string} findings
 * @returns {string}
 */
export function gateAskReason(findings: string): string;
/**
 * Non-blocking reminder for tool calls after the first ask: the injection is
 * still present, but the user was already asked once this session, so this rides
 * as context rather than re-prompting on every call.
 * @returns {string}
 */
export function gateReminderContext(): string;
/** The project the hooks are guarding; the alert paths are keyed to it. */
export const PROJECT_DIR: string;
/** Findings the SessionStart scanner could not clean, for the PreToolUse gate. */
export const ALERT_FILE: string;
export const ALERT_ACK_FILE: string;
