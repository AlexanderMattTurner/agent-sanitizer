/** @param {string[]} changed */
export function authoredContext(changed: string[]): string;
/**
 * Strip authored stego / terminal-control sequences from the model-authored
 * fields of a tool call. Returns the updated input plus a per-field description
 * of what was stripped, or null when nothing changed. Throws on internal error
 * (caller fails closed).
 * @param {string} tool
 * @param {any} toolInput
 * @returns {{ updatedInput: any, changed: string[] } | null}
 */
export function sanitizeAuthoredContent(tool: string, toolInput: any): {
    updatedInput: any;
    changed: string[];
} | null;
