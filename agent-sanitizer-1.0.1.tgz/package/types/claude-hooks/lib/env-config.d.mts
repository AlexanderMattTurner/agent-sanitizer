/**
 * The inference-provider key env vars. Their values authenticate the agent to a
 * model backend, so they are masked like any other credential.
 * @returns {string[]}
 */
export function inferenceKeyVars(): string[];
/**
 * The placeholder floor: a candidate value shorter than this is too short to be a
 * real secret and is skipped by the env-bound redaction pre-gate.
 * @returns {number}
 */
export function minEnvSecretLen(): number;
/**
 * Render the published credential-noun vocabulary into the name-matcher spec:
 * the credential segments, and the trailing suffixes that mark a
 * credential-shaped name as holding a non-secret.
 *
 * The vocabulary is the SINGLE source both ecosystems read — a curated second
 * copy of these renderings is what let this matcher fall twelve segments behind
 * the engine, so a variable named `…_ACCESS_TOKEN` was never recognized as
 * credential-bearing and its value was never handed to the redactor.
 * @param {Record<string, any>} spec
 * @returns {{ segments: string[], excludeSuffixes: string[], excludeNames: string[] }}
 */
export function deriveCredentialVocabulary(spec: Record<string, any>): {
    segments: string[];
    excludeSuffixes: string[];
    excludeNames: string[];
};
/**
 * Validate a rendered name-matcher spec and build its match/exclude regexes. Pure
 * and exported so the fail-closed paths can be driven directly with a bad spec.
 * @param {Record<string, unknown>} spec
 * @returns {{ match: RegExp, exclude: RegExp }}
 */
export function buildCredentialNameRes(spec: Record<string, unknown>): {
    match: RegExp;
    exclude: RegExp;
};
/**
 * True when `name` looks like a credential-bearing variable (and isn't a known
 * non-secret lookalike).
 * @param {string} name
 * @returns {boolean}
 */
export function looksLikeCredentialVar(name: string): boolean;
/**
 * Credential-shaped env-var names present in `env` with a value long enough to be
 * a real secret (the min_secret_len floor the daemon also applies), beyond the
 * curated set. Reads the live environment so a newly-forwarded token is redacted
 * without a code change.
 * @param {Record<string, string | undefined>} [env]
 * @returns {string[]}
 */
export function dynamicSecretVars(env?: Record<string, string | undefined>): string[];
/**
 * The operator-declared extra secret variable names, or throw. A malformed entry
 * fails CLOSED — dropping it silently would leave the operator believing a
 * forwarded credential is masked while its value flows to the model verbatim.
 * @param {Record<string, string | undefined>} [env]
 * @returns {string[]}
 */
export function extraSecretVars(env?: Record<string, string | undefined>): string[];
/**
 * The env-bound redaction set: the UNION of the inference keys, the curated host
 * credentials, any credential-shaped var present in the environment, and the
 * operator's declared extras. The redactor binds the same union; every consumer
 * (the sanitize-output pre-gate, the redactor client's per-request env snapshot)
 * must mirror it exactly, else a credential value would never trip the daemon.
 * @param {Record<string, string | undefined>} [env]
 * @returns {string[]}
 */
export function envBoundSecretVars(env?: Record<string, string | undefined>): string[];
