/**
 * Numeric verbosity from _AGENT_SANITIZER_TRACE: 0 off, 1 info, 2 debug.
 * Unknown, empty, or "off" → 0.
 * @param {NodeJS.ProcessEnv} [env]
 * @returns {number}
 */
export function traceThreshold(env?: NodeJS.ProcessEnv): number;
/**
 * Emit one JSON trace line for `event` at `level` (default "info") carrying the
 * metadata `fields`. No-op when the channel is below `level`; best-effort on write.
 * @param {string} event
 * @param {Record<string, unknown>} [fields]
 * @param {"info"|"debug"} [level]
 * @returns {void}
 */
export function trace(event: string, fields?: Record<string, unknown>, level?: "info" | "debug"): void;
/** Trace-channel event names. */
export const TraceEvent: Readonly<{
    HOOK_RAN: "hook_ran";
    SCAN_INVISIBLE_CHARS_RAN: "scan_invisible_chars_ran";
}>;
