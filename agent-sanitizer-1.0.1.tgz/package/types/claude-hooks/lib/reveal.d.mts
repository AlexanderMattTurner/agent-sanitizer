/**
 * Persist one reveal's pre-splice text and return the model-facing hint naming
 * its path, or null when the write fails (the splice already protected the
 * output, so a failed convenience write must not break sanitization). The store
 * dir is verified private/uid-owned and the file is created symlink-refusingly
 * (O_EXCL): the path is content-addressed, so an attacker who chose the page bytes
 * can precompute it and pre-plant a symlink there to redirect this write onto a
 * victim file — writeFileNoFollow refuses that instead of following it.
 * @param {string} content
 * @returns {string | null}
 */
export function persistReveal(content: string): string | null;
/**
 * True when this PostToolUse event is a Read of a reveal sidecar file, so its
 * output must be marked untrusted even though Read is otherwise a trusted local
 * tool. Containment is checked against the lexically resolved path with a
 * trailing separator so a sibling dir sharing the prefix (…-reveal-evil) cannot
 * pass. The model picks what it Reads (no attacker-planted symlinks to escape),
 * so lexical resolution — not realpath — is the right boundary here.
 * @param {string} toolName
 * @param {any} toolInput
 * @returns {boolean}
 */
export function isRevealRead(toolName: string, toolInput: any): boolean;
/** Envelope prepended to a reveal-file Read so its bytes are framed as untrusted. */
export const REVEAL_READ_ENVELOPE: string;
