/**
 * The hook's CLI: scan the instruction files, auto-clean what it can, persist
 * the alert for the PreToolUse gate otherwise. Exported so a bundle entry
 * (which must claim the CLI slot before this module loads) can run the exact
 * same scan instead of duplicating it.
 * @returns {Promise<void>}
 */
export function cliMain(): Promise<void>;
/**
 * @param {string} run
 * @returns {{ method: string, decoded: string }}
 */
export function decodeRun(run: string): {
    method: string;
    decoded: string;
};
/**
 * @param {string} dir
 * @returns {string[]}
 */
export function findMdFiles(dir: string): string[];
/**
 * Every subdirectory instruction file (CLAUDE.md, CLAUDE.local.md, AGENTS.md)
 * under `dir`. Claude Code loads these as project instructions on entry to their
 * containing directory — a load path that bypasses the PostToolUse sanitizer — so
 * a payload planted in e.g. `packages/foo/CLAUDE.md` reaches the model uncleaned
 * unless it is scanned here. Skips node_modules; `**` skips dot directories by
 * default (`.git`, and `.claude`, which the caller scans separately).
 * @param {string} dir
 * @returns {string[]}
 */
export function findInstructionFiles(dir: string): string[];
/**
 * @param {string} filePath
 * @returns {Array<{ line: number, charCount: number, method: string, decoded: string }>}
 */
export function scanFile(filePath: string): Array<{
    line: number;
    charCount: number;
    method: string;
    decoded: string;
}>;
import { ALERT_FILE } from "./lib/invisible-alert.mjs";
import { ALERT_ACK_FILE } from "./lib/invisible-alert.mjs";
export let LONG_RUN_RE: RegExp;
export let LONG_RUN_THRESHOLD: 10;
export let TOTAL_INVISIBLE_THRESHOLD: 30;
/**
 * @param {Array<{
 *   file: string,
 *   findings: Array<{ line: number, charCount: number, method: string, decoded: string }>,
 * }>} allFindings
 * @returns {string}
 */
export function formatReport(allFindings: Array<{
    file: string;
    findings: Array<{
        line: number;
        charCount: number;
        method: string;
        decoded: string;
    }>;
}>): string;
export { ALERT_FILE, ALERT_ACK_FILE };
