/**
 * Judge a normalized prompt-submit event. Agent-agnostic: consumes the
 * control-plane ToolCallEvent and returns a Verdict, so the same prompt gate
 * renders through any agent adapter, not just Claude's. Throws (into the
 * calling hook's catch) when the sanitizer package never loaded — this hook is
 * the only defense on user input, so a prompt it cannot classify must block,
 * never pass through.
 * @param {import("agent-control-plane-core").ToolCallEvent} event
 * @param {((s: string) => string) | null} [strip]  the ANSI stripper (defaults
 *   to the package's stripAnsiFully; injectable so the fail-closed path is testable)
 * @param {Partial<typeof USER_PROMPT_MESSAGES>} [overrides]  reason overrides,
 *   merged over the defaults so a partial table can never leave a field unset
 * @returns {import("agent-control-plane-core").Verdict}
 */
export function judgeSanitizeUserPrompt(event: import("agent-control-plane-core").ToolCallEvent, strip?: ((s: string) => string) | null, overrides?: Partial<typeof USER_PROMPT_MESSAGES>): import("agent-control-plane-core").Verdict;
/**
 * @param {() => Promise<any> | any} read
 * @param {(chunk: string) => void} write
 * @param {((s: string) => string) | null} [strip]  the ANSI stripper (defaults
 *   to the package's stripAnsiFully; injectable so the fail-closed path is testable)
 * @param {Partial<typeof USER_PROMPT_MESSAGES>} [overrides]  reason overrides,
 *   merged over the defaults so a partial table can never leave a field unset
 * @returns {Promise<void>}
 */
export function main(read: () => Promise<any> | any, write: (chunk: string) => void, strip?: ((s: string) => string) | null, overrides?: Partial<typeof USER_PROMPT_MESSAGES>): Promise<void>;
/** @type {typeof import("agent-sanitizer/prompt").classifyPrompt} */
export let classifyPrompt: typeof import("agent-sanitizer/prompt").classifyPrompt;
/**
 * The reasons this gate emits, as a table a host overrides. A host that knows
 * which of ITS files wires the adapter, and what a reader should do about a
 * failure, can say so — the package cannot, since it has no idea where it is
 * installed. Every field is a plain string or a string-returning function, so
 * an override is auditable next to the default it replaces.
 * @type {Readonly<{
 *   unknownEvent: string,
 *   blockContext: string,
 *   sgrNote: string,
 *   hookFailed: (cause: string) => string,
 *   remedy: string,
 * }>}
 */
export const USER_PROMPT_MESSAGES: Readonly<{
    unknownEvent: string;
    blockContext: string;
    sgrNote: string;
    hookFailed: (cause: string) => string;
    remedy: string;
}>;
