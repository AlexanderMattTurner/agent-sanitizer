/** @typedef {{ segments: string[], fieldNamePatterns: string[], nonSecretSegments: string[] }} CredentialNames */
/** Validate `spec` and return its renderings — the JavaScript twin of
 * `agent_sanitizer.secrets.parse_credential_names`, over the same file.
 *
 * A malformed spec throws rather than degrading. An empty list would render an
 * alternation that matches nothing (every credential forwarded verbatim) and a
 * part carrying a regex metacharacter one that matches everything (all output
 * blanked), so neither may reach a consumer's matcher.
 * @param {Record<string, unknown>} spec @returns {CredentialNames} */
export function parseCredentialNames(spec: Record<string, unknown>): CredentialNames;
/** The validated renderings of the packaged vocabulary, memoized.
 *
 * Read lazily, never at module load: a static importer that crashed at LOAD would
 * abort before its own fail-closed catch installs, and a guardrail that fails to
 * load is a guardrail that fails OPEN. Deferring to first use routes a missing or
 * corrupt data file into the caller's catch instead.
 * @returns {CredentialNames} */
export function credentialNames(): CredentialNames;
/** @typedef {"trailing" | "any-segment"} CredentialNameScope */
/** A predicate: does this env-var NAME hold a credential?
 *
 * `scope` selects the rule — `"trailing"` for a redactor (the noun must be the
 * name's last run), `"any-segment"` for an env scrub (the noun may be any run).
 * See this module's header for why that choice belongs to the caller.
 *
 * `declineNonSecret` applies the vocabulary's `nonSecretSuffixes`: a name ending
 * in one holds an identifier or a public key (`AWS_ACCESS_KEY_ID`), not a secret.
 * Leave it on for a redactor, where redacting an identifier out of output is a
 * visible defect; turn it off for a scrub whose failure to strip is the worse
 * error. It is applied to the name's trailing run under both scopes, because a
 * non-secret marker only means anything at the end of a name.
 *
 * The returned predicate closes over the parsed vocabulary, so build it once and
 * reuse it — the parse and validation are not repeated per name.
 *
 * @param {{ scope?: CredentialNameScope, declineNonSecret?: boolean, spec?: Record<string, unknown> }} [options]
 * @returns {(name: string) => boolean} */
export function credentialNameMatcher(options?: {
    scope?: CredentialNameScope;
    declineNonSecret?: boolean;
    spec?: Record<string, unknown>;
}): (name: string) => boolean;
export type CredentialNames = {
    segments: string[];
    fieldNamePatterns: string[];
    nonSecretSegments: string[];
};
export type CredentialNameScope = "trailing" | "any-segment";
