/**
 * Strip ANSI escape sequences to a fixed point. Removing one sequence can
 * reconstitute another around it (a lone ESC left of `ESC[32m[0m` gains the
 * trailing `[0m` once the inner sequence is removed, forming a brand-new valid
 * sequence the single pass would miss), so iterate until stable: every changed
 * pass consumes at least one ESC introducer, so the pass count is bounded by
 * the input's ESC count, and ANSI-free text exits after one pass.
 * @param {string} input
 * @returns {string}
 */
export function stripAnsiFully(input: string): string;
/**
 * Layer 1: ANSI + invisible-char strip with a result guaranteed free of every
 * raw ANSI control introducer (7-bit ESC U+001B and the whole 8-bit C1 control
 * block U+0080–U+009F: CSI, the DCS/SOS/OSC/PM/APC string introducers, and ST).
 *
 * Removing an invisible character can reconstitute an escape its split hid from
 * the ANSI pass (`ESC`<ZWSP>`[32m` → `ESC[32m`), so strip ANSI again after the
 * invisible pass — but only when stripInvisible changed something, since
 * reconstitution is impossible otherwise and the re-strip is a wasted pass on
 * the hot clean path. The ANSI strip still cannot match an *incomplete*
 * reconstituted sequence (a lone `ESC[` left when an inner complete sequence is
 * removed from a nested split), so a final sweep removes every residual raw
 * introducer outright — that sweep, not the regex matching, is the guarantee
 * that no control introducer survives. `deAnsi` is the ANSI strip of the
 * original (invisible runs intact), the scope a LONG_RUN payload check needs.
 * @param {string} text
 * @returns {{ cleaned: string, deAnsi: string, found: string[] }}
 */
export function applyLayer1(text: string): {
    cleaned: string;
    deAnsi: string;
    found: string[];
};
export const LONE_SURROGATE_RE: RegExp;
