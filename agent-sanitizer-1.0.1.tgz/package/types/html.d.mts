/**
 * @param {string} styleStr
 * @returns {boolean}
 */
export function isHiddenStyle(styleStr: string): boolean;
/**
 * True for an element a rendered page would not show: `hidden` attribute or a
 * hiding inline style. Works on both hast nodes and parseHtmlTag results.
 * @param {any} node
 * @returns {boolean}
 */
export function isHiddenElement(node: any): boolean;
/**
 * @param {string} htmlValue
 * @returns {string | null}
 */
export function isHiddenOpen(htmlValue: string): string | null;
/**
 * @param {string} htmlValue
 * @returns {string | null}
 */
export function closingTagName(htmlValue: string): string | null;
/**
 * Replace each range of `text` with its kind's placeholder, preserving every
 * byte outside the ranges verbatim. Overlapping/nested ranges are merged
 * (defense-in-depth — the scanners emit disjoint ranges).
 * @param {string} text
 * @param {Array<{start: number, end: number, kind: "comment" | "hidden"}>} ranges
 * @returns {string}
 */
export function spliceRanges(text: string, ranges: Array<{
    start: number;
    end: number;
    kind: "comment" | "hidden";
}>): string;
/**
 * Scan raw HTML for hidden content to strip and preserved tags to report.
 * Returned ranges are offsets into `html`; comments and hidden elements span
 * the whole element including its content (rehype positions cover open tag
 * through matching close, and parse5 extends an unclosed element to the end
 * of the fragment — fail-closed for truncated markup).
 * @param {string} html
 * @returns {{ ranges: Array<{start: number, end: number, kind: "comment" | "hidden"}>, warned: ReturnType<typeof newWarned> }}
 */
export function scanHtmlFragment(html: string): {
    ranges: Array<{
        start: number;
        end: number;
        kind: "comment" | "hidden";
    }>;
    warned: ReturnType<typeof newWarned>;
};
/**
 * @param {string} text
 * @returns {boolean}
 */
export function looksLikeHtmlSource(text: string): boolean;
/**
 * Layer 2 over web-ingress text: splice out HTML comments and hidden elements
 * (placeholders mark the cuts; all other bytes are preserved verbatim) and
 * count preserved scripting/resource tags for the caller's warning. Returns
 * null when there is nothing to strip and nothing to report.
 * @param {string} text
 * @returns {{ text: string, removed: { comments: number, hidden: number }, warned: { tags: Record<string, number>, dataSrc: number } } | null}
 */
export function sanitizeHtml(text: string): {
    text: string;
    removed: {
        comments: number;
        hidden: number;
    };
    warned: {
        tags: Record<string, number>;
        dataSrc: number;
    };
} | null;
/**
 * @param {string} url
 * @returns {string | null}
 */
export function checkExfilUrl(url: string): string | null;
/**
 * Host of a flagged URL — enough for the warning to name the destination
 * without echoing the payload-bearing query/fragment.
 * @param {string} url
 * @returns {string}
 */
export function urlHost(url: string): string;
/**
 * Layer 3: report data-exfil-shaped URLs in markdown links/images/definitions
 * and HTML attributes (src/href/background/srcset/ping, form action/formaction,
 * meta-refresh). Detection only — the text is never modified; the caller
 * surfaces the threats as a warning.
 * @param {string} text
 * @returns {Array<{ isImage: boolean, reason: string, target: string }> | null}
 */
export function detectExfil(text: string): Array<{
    isImage: boolean;
    reason: string;
    target: string;
}> | null;
export const REPORTED_TAGS: Set<string>;
export const COMMENT_PLACEHOLDER: "[HTML comment removed]";
export const HIDDEN_PLACEHOLDER: "[hidden HTML removed]";
export const UNPARSEABLE_PLACEHOLDER: "[HTML unparseable \u2014 withheld]";
export const DATA_URI_LENGTH_THRESHOLD: 4096;
/** @returns {{ tags: Record<string, number>, dataSrc: number }} */
declare function newWarned(): {
    tags: Record<string, number>;
    dataSrc: number;
};
import { HTML_TAG_PRESENT } from "./gates.mjs";
import { MD_LINK_HINT } from "./gates.mjs";
import { SECRET_HINT } from "./gates.mjs";
import { SECRET_HINT_EXT } from "./gates.mjs";
import { matchesSecretHint } from "./gates.mjs";
export { HTML_TAG_PRESENT, MD_LINK_HINT, SECRET_HINT, SECRET_HINT_EXT, matchesSecretHint };
