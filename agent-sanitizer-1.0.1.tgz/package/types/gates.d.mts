/**
 * True when either pre-gate alternation shape-matches `text`. Split into two
 * literals (see SECRET_HINT) and OR'd so neither grows into a
 * polynomial-backtracking shape.
 * @param {string} text
 * @returns {boolean}
 */
export function matchesSecretHint(text: string): boolean;
/**
 * Cheap, dependency-free pre-gates shared by the HTML layer (Layers 2 & 3) and
 * re-exported from both the package root and the `./html` subpath.
 *
 * These are pulled out of `html.mjs` so the package root can re-export them
 * without dragging in the heavy remark/rehype/unified graph: a static
 * `export … from "./html.mjs"` would eagerly evaluate that ~200ms module on
 * every root import, defeating the lazy-load design. This module imports
 * nothing, so re-exporting it is free.
 */
/**
 * Matches any HTML tag-like construct: opening tags, closing tags (`</`),
 * comments and bogus declarations (`<!`), and processing instructions / bogus
 * comments (`<?…?>`, which the HTML tokenizer hides exactly like a comment).
 * The `<?` arm is what lets a PI-only document reach Layer 2's bogus-comment
 * splice; without it such a document would skip the pipeline entirely. Gate for
 * Layer 2 (HTML sanitization) and the HTML img/a exfil path in Layer 3.
 */
export const HTML_TAG_PRESENT: RegExp;
/**
 * Matches markdown link/image syntax (`](`, `![`) and reference link
 * definitions (`[label]: url` at line start). Gate for Layer 3 (markdown
 * exfiltration detection).
 */
export const MD_LINK_HINT: RegExp;
/** @type {RegExp} */
export const SECRET_HINT: RegExp;
/** @type {RegExp} */
export const SECRET_HINT_EXT: RegExp;
